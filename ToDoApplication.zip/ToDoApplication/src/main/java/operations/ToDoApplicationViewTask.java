package main.java.operations;

import main.java.exception.TaskNotYetAddedException;
import main.java.structure.ToDoApplicationObjects;

import java.util.ArrayList;

/** It just extracts the details from the arraylist of the objects*/
public class ToDoApplicationViewTask {
    ToDoApplicationObjects taskDetails;
    public void viewTasks(ArrayList<ToDoApplicationObjects> tasks){
        int taskSize = tasks.size();
        if(taskSize==0){
            try{
                System.out.println("-*-*-*-*-*--*-*-*-*-*--*-*-*-*-*--*-*-*-*-*-");
                throw new TaskNotYetAddedException("No Tasks Yet Added!");
            }
            catch (TaskNotYetAddedException ex){
                System.out.println(ex.getMessage());
            }
            System.out.println("-*-*-*-*-*--*-*-*-*-*--*-*-*-*-*--*-*-*-*-*-");
        }
        else {
            for (int i = 0; i < taskSize; i++) {
                taskDetails = tasks.get(i);
                System.out.println("-*-*-*-*-*--*-*-*-*-*--*-*-*-*-*--*-*-*-*-*-");
                System.out.println("Title: " + taskDetails.getTitle());
                System.out.println("Description: " + taskDetails.getDescription());
                System.out.println("Due Date: " + taskDetails.getDueDate());
                System.out.println("Is Completed: " + taskDetails.getIsCompleted());
                System.out.println("Is Completed Before Due Date: " + taskDetails.getCompletedBeforeDueDate());
            }
            System.out.println("-*-*-*-*-*--*-*-*-*-*--*-*-*-*-*--*-*-*-*-*-");
        }
    }
}
