package main.java.operations;

import main.java.exception.TaskNotFoundException;
import main.java.exception.TaskNotYetAddedException;
import main.java.structure.ToDoApplicationObjects;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Remove the task for the to-do list
 * It does this in 3 steps:
 * 1. checks if the tasks are added in the list or not if not then an appropriate exception is thrown
 * 2. if tasks exists then it find the appropriate tasks required
 * 3. if tasks found then delete it and if it doesn't exists amongst the given tasks then an appropriate exception is thrown*/
public class ToDoApplicationRemoveTask {
    static  ToDoApplicationObjects taskDetails;
    public void removeTask(Scanner scanInput, ArrayList<ToDoApplicationObjects> tasks){
        int size = tasks.size();
        // if arraylist is empty or not
        if(size == 0){
            try {
                throw new TaskNotYetAddedException("Tasks Not yet Added!");
            } catch (TaskNotYetAddedException e) {
                System.out.println(e.getMessage());
            }
        }
        else{
            System.out.print("Enter title of task: ");
            String taskTitle = scanInput.nextLine();
            taskTitle = scanInput.nextLine();
            taskTitle.trim();
            boolean taskExists = false;
            //find the tasks and delete it
            for (int i = 0; i < size; i++) {
                taskDetails = tasks.get(i);
                if (taskDetails.getTitle().equalsIgnoreCase(taskTitle)) {
                    taskExists = true;
                    tasks.remove(taskDetails);
                    System.out.println("Task Removed Successfully!");
                    break;
                }
            }

            // if task doesn't exists then throw an exception
            if (!taskExists) {
                try {
                    throw new TaskNotFoundException("Task Doesn't Exists!");
                } catch (TaskNotFoundException e) {
                    System.out.println(e.getMessage());
                }
            }
        }
    }
}
