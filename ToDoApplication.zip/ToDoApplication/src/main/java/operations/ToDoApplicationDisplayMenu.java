package main.java.operations;

import java.util.Scanner;

/**
 * Display the menu to the user and ask for his choice*/

public class ToDoApplicationDisplayMenu {
    public int displayMenu(Scanner scanInput){
        System.out.println("Press");
        System.out.println("1. Add Task");
        System.out.println("2. Mark a Task as Completed");
        System.out.println("3. View Tasks");
        System.out.println("4. Remove a Task");
        System.out.println("5. Exit");
        System.out.print("Enter your choice: ");
        return scanInput.nextInt();
    }
}
