package main.java.operations;

import main.java.exception.TaskNotFoundException;
import main.java.exception.TaskNotYetAddedException;
import main.java.structure.ToDoApplicationObjects;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;

/** It updates the status of the task given by the user
 * It does this in 3 steps:
 * 1. If the arraylist is empty then an appropriate exception is thrown
 * 2. O/w the task is found and its completed status is updated and checked if it is done on time or not
 * 3. If task doesn't exists then it will throw an appropriate exception*/
public class ToDoApplicationUpdateTask {
    static ToDoApplicationObjects taskDetails;
    public void updateTasks(Scanner scanInput, ArrayList<ToDoApplicationObjects> tasks){
        System.out.print("Enter title of task: ");
        String taskTitle = scanInput.nextLine();
        taskTitle = scanInput.nextLine();
        taskTitle.trim();
        boolean taskExists = false;
        int size = tasks.size();
        if(size==0){
            try{
                System.out.println("-*-*-*-*-*--*-*-*-*-*--*-*-*-*-*--*-*-*-*-*-");
                throw new TaskNotYetAddedException("No Tasks Yet Added!");
            }
            catch (TaskNotYetAddedException ex){
                System.out.println(ex.getMessage());
            }
            System.out.println("-*-*-*-*-*--*-*-*-*-*--*-*-*-*-*--*-*-*-*-*-");
        }
        else {
            for (int i = 0; i < size; i++) {
                taskDetails = tasks.get(i);
                if (taskDetails.getTitle().equalsIgnoreCase(taskTitle)) {
                    taskExists = true;
                    taskDetails.setIsCompleted(true);
                    if (taskDetails.getDueDate().isAfter(LocalDate.now())) {
                        taskDetails.setCompletedBeforeDueDate(true);
                    }
                    System.out.println("Task Updated Successfully!");
                }
            }
            if (!taskExists) {
                try {
                    throw new TaskNotFoundException("Task Doesn't Exists!");
                } catch (TaskNotFoundException e) {
                    System.out.println(e.getMessage());
                }
            }
        }
    }
}
