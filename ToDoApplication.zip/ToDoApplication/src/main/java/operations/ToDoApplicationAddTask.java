package main.java.operations;

import main.java.structure.ToDoApplicationObjects;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

/**
 * It is used to add new tasks to the to-do application*/
public class ToDoApplicationAddTask {
    public ToDoApplicationObjects addNewTask(Scanner scanInput){
        System.out.println("=========================================");
        System.out.print("Enter task title: ");
        String title = scanInput.nextLine();
        title = scanInput.nextLine();
        System.out.print("Enter task description: ");
        String description = scanInput.nextLine();
        System.out.print("Enter due date (DD-MM-YYYY): ");
        String date = scanInput.nextLine();

        LocalDate dueDate = parseDate(date);
        return new ToDoApplicationObjects(title, description, dueDate, false, false);
    }

    // converts the string format of the date to LocalDate format
    private static LocalDate parseDate(String date) {
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        LocalDate dueDate = LocalDate.now();
        try{
            dueDate =  LocalDate.parse(date, dateTimeFormatter);
            return dueDate;
        }
        catch (IllegalArgumentException ex){
            ex.printStackTrace();
        }
        return dueDate;
    }
}
