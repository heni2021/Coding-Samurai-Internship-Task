package main.java.structure;

import java.time.LocalDate;

public class ToDoApplicationObjects {
    private String title; // represents the title of the task
    private String description; // represents the description of the task
    private LocalDate dueDate; // it represents the due date of the task
    private Boolean isCompleted = false; // current status of task

    private Boolean completedBeforeDueDate = false; // if it is completed on time or not

    // constructor to initialize the value of objects
    public ToDoApplicationObjects(String _title, String _description, LocalDate _dueDate, Boolean _isCompleted, Boolean _completedBeforeDueDate){
        this.setTitle(_title);
        this.setDescription(_description);
        this.setDueDate(_dueDate);
        this.setIsCompleted(_isCompleted);
        this.setCompletedBeforeDueDate(_completedBeforeDueDate);
    }

    ToDoApplicationObjects(){

    }

    //getters and setters for the variables to set value and fetch them
    public void setTitle(String _title){
        this.title = _title;
    }

    public void setDescription(String _description){
        this.description = _description;
    }

    public void setDueDate(LocalDate _dueDate){
        this.dueDate = _dueDate;
    }

    public void setIsCompleted(Boolean _isCompleted){
        this.isCompleted = _isCompleted;
    }

    public void setCompletedBeforeDueDate(Boolean _completedBeforeDueDate){
        this.completedBeforeDueDate = _completedBeforeDueDate;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public LocalDate getDueDate() {
        return dueDate;
    }

    public Boolean getIsCompleted() {
        return isCompleted;
    }

    public Boolean getCompletedBeforeDueDate() {
        return completedBeforeDueDate;
    }
}
