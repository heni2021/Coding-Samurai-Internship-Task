package main.java.controller;

import main.java.operations.*;
import main.java.structure.ToDoApplicationObjects;

import java.util.ArrayList;
import java.util.Scanner;

public class ToDoApplicationController {
    static ToDoApplicationAddTask addTask;
    static ToDoApplicationViewTask viewTask;
    static ToDoApplicationUpdateTask updateTask;
    static ToDoApplicationDisplayMenu display;
    static ToDoApplicationRemoveTask remove;

    public static void main(String[] args) {

        // Scanner class object to scan the input from user
        Scanner scanInput = new Scanner(System.in);

        initializeObjects();

        int choice;

        // ArrayList to save the objects of the tasks
        ArrayList<ToDoApplicationObjects> tasks = new ArrayList<>();

        outerLoop: while(true) {
            choice = display.displayMenu(scanInput);
            // to invoke all the operations from the operations package
            switch (choice) {
                case 1:
                    ToDoApplicationObjects newTask = addTask.addNewTask(scanInput);
                    tasks.add(newTask);
                    System.out.println("Task Added Successfully!");
                    break;
                case 2:
                    updateTask.updateTasks(scanInput, tasks);
                    break;
                case 3:
                    viewTask.viewTasks(tasks);
                    break;
                case 4:
                    remove.removeTask(scanInput,tasks);
                    break;
                case 5:
                    System.out.println("**********************************************");
                    System.out.println("Thank you for using Application");
                    System.out.println("**********************************************");
                    break outerLoop;
                default:
                    System.out.println("Incorrect Choice!");
                    break;
            }
        }
        //If you want to reduce it to one line without using try-with-resources
        // you can still close the Scanner in a single line
        scanInput.close();
    }

    private static void initializeObjects() {
        addTask = new ToDoApplicationAddTask();
        viewTask = new ToDoApplicationViewTask();
        updateTask = new ToDoApplicationUpdateTask();
        display = new ToDoApplicationDisplayMenu();
        remove = new ToDoApplicationRemoveTask();
    }
}
