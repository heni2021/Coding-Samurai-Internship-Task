package main.java.exception;

/**
 * To throw an exception if the tasks doesn't exist*/
public class TaskNotFoundException extends  Exception{
    public TaskNotFoundException(String message){
        super(message);
    }
}