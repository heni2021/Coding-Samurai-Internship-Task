package main.java.exception;

/**
 * If the arraylist is empty then this exception is thrown */
public class TaskNotYetAddedException extends  Exception{
    public TaskNotYetAddedException(String message){
        super(message);
    }
}
