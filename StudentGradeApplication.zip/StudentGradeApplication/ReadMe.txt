Grading Scheme :-
There are two components which has 60% and 40% of contribution in grade calculation
1. Continuous Evaluation (CE Component) - 60%
2. Final Exam / External Exam - 40%

Continuous Evaluation Component contains:-
1. Test / Class Test - 35 Marks
2. Quiz / Sessional  - 35 Marks
3. Innovative Assignment - 30 Marks
-----------------------------------------
Total Marks          - 100 Marks
-----------------------------------------

To compute total marks for grading criteria is given by:
Total Marks = (CE Component Marks)*0.6 + (Final Exam Marks)*0.4

**** Grading Criteria :- ****
| Total Marks      :  Grades |
| >= 95            :    A+   |
| >=90             :    A    |
| >= 85            :    B+   |
| >=80             :    B    |
| >=70             :    C    |
| >=65             :    D    |
| >=60             :    E    |
| <60              :    F    |