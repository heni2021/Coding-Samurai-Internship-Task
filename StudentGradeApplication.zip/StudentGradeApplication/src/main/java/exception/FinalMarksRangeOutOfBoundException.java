package main.java.exception;

/**This is thrown if final exam marks are not in between 0 to 100*/
public class FinalMarksRangeOutOfBoundException extends Exception{
    public FinalMarksRangeOutOfBoundException(String message){
        super(message);
    }
}
