package main.java.exception;

/**This is thrown if quiz marks are not between 0 to  35 */
public class QuizzRangeOutOfBoundException extends Exception{
    public QuizzRangeOutOfBoundException(String message){
        super(message);
    }
}
