package main.java.exception;

/**This is thrown if test marks are not between 0 to  35 */

public class TestGradeOutOfBoundException extends Exception{
    public TestGradeOutOfBoundException(String message){
        super(message);
    }
}
