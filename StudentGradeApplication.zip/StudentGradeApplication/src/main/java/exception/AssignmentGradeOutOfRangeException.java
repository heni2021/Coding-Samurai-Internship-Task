package main.java.exception;

/** This is thrown if assignment marks are not between 0 to 30*/
public class AssignmentGradeOutOfRangeException extends Exception{
    public AssignmentGradeOutOfRangeException(String message){
        super(message);
    }
}