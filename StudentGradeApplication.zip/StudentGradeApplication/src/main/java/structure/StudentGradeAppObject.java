package main.java.structure;

// this follows the structure of the grading app and its contents
public class StudentGradeAppObject {
    private String courseName; // stores course name
    private double quizMarks; // stores quiz marks
    private double assignmentMarks; // stores assignment marks
    private double testMarks; // stores test marks
    private double finalExamMarks; // stores final exam marks


    // parameterized constructor for initializing the values
    public StudentGradeAppObject(String _courseName, double _quizMarks, double _assignmentMarks, double _testMarks, double _finalExamMarks) {
        setCourseName(_courseName);
        setQuizMarks(_quizMarks);
        setAssignmentMarks(_assignmentMarks);
        setTestMarks(_testMarks);
        setFinalExamMarks(_finalExamMarks);
    }

    // default constructor
    public StudentGradeAppObject(){

    }

    // Getters and setters for all the private variables
    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public double getQuizMarks() {
        return quizMarks;
    }

    public void setQuizMarks(double quizMarks) {
        this.quizMarks = quizMarks;
    }

    public double getAssignmentMarks() {
        return assignmentMarks;
    }

    public void setAssignmentMarks(double assignmentMarks) {
        this.assignmentMarks = assignmentMarks;
    }

    public double getTestMarks() {
        return testMarks;
    }

    public void setTestMarks(double testMarks) {
        this.testMarks = testMarks;
    }

    public double getFinalExamMarks() {
        return finalExamMarks;
    }

    public void setFinalExamMarks(double finalExamMarks) {
        this.finalExamMarks = finalExamMarks;
    }
}
