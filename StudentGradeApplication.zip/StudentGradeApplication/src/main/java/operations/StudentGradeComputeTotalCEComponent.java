package main.java.operations;

import main.java.structure.StudentGradeAppObject;

import java.util.ArrayList;

// computing CE component marks i.e. test marks + quiz marks + assignment marks
public class StudentGradeComputeTotalCEComponent {
    static  StudentGradeAppObject newData;
    public void computeTotal(int numberOfChoices, ArrayList<StudentGradeAppObject> coursesGrades, ArrayList<Double> totalMarks) {
        for (int i = 0; i < numberOfChoices; i++) {
            newData = coursesGrades.get(i);
            totalMarks.add(newData.getAssignmentMarks()+ newData.getQuizMarks()+ newData.getTestMarks());
        }
    }
}
