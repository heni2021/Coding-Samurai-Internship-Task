package main.java.operations;

import main.java.structure.StudentGradeAppObject;

import java.util.ArrayList;
import java.util.HashMap;

// this class is used to print the results computed in hashmap of grades
public class StudentGradeAppPrintGrades {
    static StudentGradeAppObject newData;
    public void printOutputGrades(int numberOfChoices, HashMap<String, String> grades, ArrayList<Double> totalMarks, ArrayList<StudentGradeAppObject> coursesGrades) {
        System.out.println("Name \t \t | CE Component Marks | Final Exam Marks | Grades");
        for (int i = 0; i < numberOfChoices; i++) {
            newData = coursesGrades.get(i);
            System.out.println(newData.getCourseName()+" | "+totalMarks.get(i)+" | "+ newData.getFinalExamMarks()+" || "+grades.get(newData.getCourseName()));
        }
        System.out.println("-*-*-*-*--*-*-*-*--*-*-*-*--*-*-*-*--*-*-*-*-");
    }
}
