package main.java.operations;

import main.java.exception.AssignmentGradeOutOfRangeException;
import main.java.exception.FinalMarksRangeOutOfBoundException;
import main.java.exception.QuizzRangeOutOfBoundException;
import main.java.exception.TestGradeOutOfBoundException;
import main.java.structure.StudentGradeAppObject;

import java.util.ArrayList;
import java.util.Scanner;

// this scans the input and check for all the necessary exceptions and handle them
public class StudentGradeScanInput {
    static StudentGradeAppObject newData;
    public void scanInputGrades(int numberOfChoices, Scanner scanInput, ArrayList<StudentGradeAppObject> coursesGrades){
        String name;
        double quiz, assignment, finalExam, test;
        for(int i=0;i<numberOfChoices;i++){
            System.out.println("-*-*-*-*--*-*-*-*--*-*-*-*--*-*-*-*--*-*-*-*-");
            System.out.print("Enter course name: ");
            name = scanInput.nextLine();
            name = scanInput.nextLine();

            while(true) {
                System.out.print("Enter test marks: ");
                test = scanInput.nextDouble();
                if (test > 35 || test < 0) {
                    try {
                        System.out.println("=======================================================");
                        throw new TestGradeOutOfBoundException("Test Marks should be between 0 to 35");
                    } catch (TestGradeOutOfBoundException ex) {
                        System.out.println(ex.getMessage());
                    }
                    System.out.println("=======================================================");
                }
                else{
                    break;
                }
            }

            while(true) {
                System.out.print("Enter quiz marks: ");
                quiz = scanInput.nextDouble();
                if(quiz > 35 || quiz <0){
                    try{
                        System.out.println("=======================================================");
                        throw new QuizzRangeOutOfBoundException("Quiz Marks should be between 0 to 35");
                    }
                    catch(QuizzRangeOutOfBoundException ex){
                        System.out.println(ex.getMessage());
                    }
                    System.out.println("=======================================================");
                }
                else{
                    break;
                }
            }

            while(true) {
                System.out.print("Enter assignment marks: ");
                assignment = scanInput.nextDouble();
                if(assignment > 30 || assignment < 0){
                    try{
                        System.out.println("=======================================================");
                        throw new AssignmentGradeOutOfRangeException("Assignment Marks should be between 0 to 30");
                    }
                    catch(AssignmentGradeOutOfRangeException ex){
                        System.out.println(ex.getMessage());
                    }
                    System.out.println("=======================================================");
                }
                else{
                    break;
                }
            }

            while(true) {
                System.out.print("Enter final exam marks: ");
                finalExam = scanInput.nextDouble();
                if(finalExam > 100 || finalExam < 0){
                    try{
                        System.out.println("=======================================================");
                        throw new FinalMarksRangeOutOfBoundException("Final Exam Marks should be between 0 to 100");
                    }
                    catch(FinalMarksRangeOutOfBoundException ex){
                        System.out.println(ex.getMessage());
                    }
                    System.out.println("=======================================================");
                }
                else{
                    break;
                }
            }
            newData = new StudentGradeAppObject(name, quiz, assignment, test, finalExam);
            coursesGrades.add(newData);
        }
        System.out.println("-*-*-*-*--*-*-*-*--*-*-*-*--*-*-*-*--*-*-*-*-");
    }
}
