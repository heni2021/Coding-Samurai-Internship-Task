package main.java.operations;

import main.java.structure.StudentGradeAppObject;

import java.util.ArrayList;
import java.util.HashMap;

// this class computes the grades after computing total marks in total and then
// following the grading scheme
public class StudentGradeComputeGrade {
    static StudentGradeAppObject newData;
    public void computeGrade(int numberOfChoices, ArrayList<StudentGradeAppObject> coursesGrades, ArrayList<Double> totalMarks, HashMap<String, String> grades) {
        for (int i = 0; i < numberOfChoices; i++) {
            newData = coursesGrades.get(i);
            double total = totalMarks.get(i)*0.6 + newData.getFinalExamMarks()*0.4;
            if(total >= 95){
                grades.put(newData.getCourseName(), "A+");
            }
            else if(total >= 90){
                grades.put(newData.getCourseName(), "A");
            }
            else if(total >= 85){
                grades.put(newData.getCourseName(), "B+");
            }
            else if(total >= 80){
                grades.put(newData.getCourseName(), "B");
            }
            else if(total >= 70){
                grades.put(newData.getCourseName(), "C");
            }
            else if(total >= 65){
                grades.put(newData.getCourseName(), "D");
            }
            else if(total >= 60){
                grades.put(newData.getCourseName(), "E");
            }
            else{
                grades.put(newData.getCourseName(), "F");
            }
        }
    }

}
