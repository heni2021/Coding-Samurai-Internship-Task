package main.java.controller;

import main.java.operations.StudentGradeAppPrintGrades;
import main.java.operations.StudentGradeComputeGrade;
import main.java.operations.StudentGradeComputeTotalCEComponent;
import main.java.operations.StudentGradeScanInput;
import main.java.structure.StudentGradeAppObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

public class StudentGradeAppController {
    static StudentGradeScanInput scanInputGrade;
    static StudentGradeComputeTotalCEComponent ceComponent;
    static StudentGradeComputeGrade gradeCompute;
    static StudentGradeAppPrintGrades printGrades;
    public static void main(String[] args) {
        Scanner scanInput = new Scanner(System.in);

        int numberOfChoices;
        System.out.print("Enter the total number of courses: ");
        numberOfChoices = scanInput.nextInt();

        initializeObjects();

        ArrayList<StudentGradeAppObject> coursesGrades = new ArrayList<>();
        scanInputGrade.scanInputGrades(numberOfChoices, scanInput, coursesGrades);

        ArrayList<Double> totalMarks = new ArrayList<>();
        ceComponent.computeTotal(numberOfChoices, coursesGrades, totalMarks);

        HashMap<String, String> grades = new HashMap<>();
        gradeCompute.computeGrade(numberOfChoices, coursesGrades, totalMarks, grades);

        printGrades.printOutputGrades(numberOfChoices, grades, totalMarks, coursesGrades);

        scanInput.close();
    }

    private static void initializeObjects() {
        scanInputGrade = new StudentGradeScanInput();
        ceComponent = new StudentGradeComputeTotalCEComponent();
        gradeCompute = new StudentGradeComputeGrade();
        printGrades = new StudentGradeAppPrintGrades();
    }
}