package main.java.operations;

import java.util.Scanner;

// It just displays menu to the user
public class CalculatorApplicationDisplayMenu {
    public int displayMenu(Scanner scanInput){
        System.out.println("Press");
        System.out.println("1. Addition");
        System.out.println("2. Subtraction");
        System.out.println("3. Multiplication");
        System.out.println("4. Division");
        System.out.println("5. Exit");
        System.out.print("Enter your choice: ");

        return scanInput.nextInt();
    }
}
