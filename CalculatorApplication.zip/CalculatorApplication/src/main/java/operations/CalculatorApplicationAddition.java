package main.java.operations;

import java.util.InputMismatchException;
import java.util.Scanner;

// It adds two numbers and also handles input mismatch exception
public class CalculatorApplicationAddition {
    public void addNumbers(Scanner scanInput){
        double number1=0, number2=0, ans;
        try {
            System.out.print("Enter number 1: ");
            number1 = scanInput.nextInt();
            System.out.print("Enter number 2: ");
            number2 = scanInput.nextInt();
        }
        catch(InputMismatchException ex){
            System.out.println("Invalid Input Format Entered!");
        }
        ans = number1 + number2;
        System.out.println("-*-*-*--*-*-*--*-*-*--*-*-*--*-*-*--*-*-*--*-*-*-");
        System.out.println("Answer: "+number1+" + "+number2+" = "+ans);
        System.out.println("-*-*-*--*-*-*--*-*-*--*-*-*--*-*-*--*-*-*--*-*-*-");
    }
}
