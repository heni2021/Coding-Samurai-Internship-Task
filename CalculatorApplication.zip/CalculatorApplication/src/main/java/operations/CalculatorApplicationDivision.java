package main.java.operations;

import main.java.exception.CalculatorApplicationDivideByZeroException;

import java.util.InputMismatchException;
import java.util.Scanner;

// It divides two numbers and also handles input mismatch exception along with division by zero exception

public class CalculatorApplicationDivision {
    public void divideNumbers(Scanner scanInput){
        double number1=0, number2=0, ans;
        try {
            System.out.print("Enter number 1: ");
            number1 = scanInput.nextInt();
            System.out.print("Enter number 2: ");
            number2 = scanInput.nextInt();
        }
        catch(InputMismatchException ex){
            System.out.println("Invalid Input Format Entered!");
        }
        if(number2 == 0){
            try{
                throw new CalculatorApplicationDivideByZeroException("Division By Zero is Not Defined!");
            }
            catch(CalculatorApplicationDivideByZeroException ex){
                System.out.println(ex.getMessage());
            }
        }
        else {
            ans = number1 / number2;
            System.out.println("-*-*-*--*-*-*--*-*-*--*-*-*--*-*-*--*-*-*--*-*-*-");
            System.out.println("Answer: " + number1 + " / " + number2 + " = " + ans);
            System.out.println("-*-*-*--*-*-*--*-*-*--*-*-*--*-*-*--*-*-*--*-*-*-");
        }
    }
}
