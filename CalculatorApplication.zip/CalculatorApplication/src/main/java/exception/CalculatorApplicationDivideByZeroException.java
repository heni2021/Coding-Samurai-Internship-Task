package main.java.exception;

// user defined exception for division by zeros
public class CalculatorApplicationDivideByZeroException extends Exception{
    public CalculatorApplicationDivideByZeroException(String message){
        super(message);
    }
}
