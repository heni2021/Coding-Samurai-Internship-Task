package main.java.controller;

import main.java.operations.*;

import java.util.Scanner;

/**This class is the main controller of the application where all the controls begin
 * It initiates the class objects and invoke methods to perform operations*/

public class CalculatorApplicationController {
    static CalculatorApplicationAddition addOperations;
    static CalculatorApplicationSubtraction subtractOperations;
    static CalculatorApplicationMultiplication multiplyOperations;
    static CalculatorApplicationDivision divideOperations;
    static CalculatorApplicationDisplayMenu display;

    public static void main(String[] args) {
        Scanner scanInput = new Scanner(System.in);

        initializeObjects();
        int choice;

        outerLoop : while(true) {
            choice = display.displayMenu(scanInput);
            switch (choice) {
                case 1:
                    addOperations.addNumbers(scanInput);
                    break;
                case 2:
                    subtractOperations.subtractNumbers(scanInput);
                    break;
                case 3:
                    multiplyOperations.multiplyNumbers(scanInput);
                    break;
                case 4:
                    divideOperations.divideNumbers(scanInput);
                    break;
                case 5:
                    System.out.println("*******************************************");
                    System.out.println("Thank you for using Application!");
                    System.out.println("*******************************************");
                    break outerLoop;
                default:
                    System.out.println("==========================================");
                    System.out.println("Incorrect choice!");
                    System.out.println("==========================================");
                    break;
            }
        }
        scanInput.close();
    }

    // this method is used to initialize the objects of the classes so that null object value doesn't point to the methods
    private static void initializeObjects() {
        addOperations = new CalculatorApplicationAddition();
        subtractOperations = new CalculatorApplicationSubtraction();
        multiplyOperations = new CalculatorApplicationMultiplication();
        divideOperations = new CalculatorApplicationDivision();
        display = new CalculatorApplicationDisplayMenu();
    }
}